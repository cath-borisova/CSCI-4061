How work was split up between everyone in the group:
Ruth
- completed
    - run control 
    - nonblocking function and nonblocking implementation in main
    - finished child process in main
    - added to fav ok but fixing how we checked on_favorites
    - majority of error checking

Katya
- completed the majority of the intermediate code
    - new_tab_created_cb
    - main
    - handle_uri
    - fav_ok
    - update_favorites

Alice
- completed 
    - uri_entered_cb
    - menu_item_selected_cb
    - init_favorites
    - added error checking to fav_ok
    - added error checking for MAX_TAB and bad format
    - debugged handle_uri
    - updated Makefile to include README

Ruth & Katya: 
- worked on debugging and testing use cases
    - debugged issues with pipes, max tabs, perror(), alerts(), favorites

