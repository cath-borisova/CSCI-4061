CSCI-4061 Fall 2022 – Project #4
Group Member #1: Katya Borisova boris040
    -completed init()
    -completed accept_connection()
    -did first draft of get_request()
Group Member #2: Alice Zhang zhan6698
    -completed get_request()
    -debugged init()
    -completed initial draft of return_result()
    -completed return_error()
Group Member #3: Ruth Mesfin mesfi020
    -debugging
    -testing
    -getting rid of warnings / improving readability 
    -documentation
    -added error checking
Everyone: 
    -debugged return_result()
 
 
